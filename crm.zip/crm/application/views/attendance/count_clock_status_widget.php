<div id="clock-status-widget" class="box b-t bg-white">
    <div class="box-content widget-container b-r">
        <div class="panel-body ">
            <h1><?php echo $members_clocked_in; ?></h1>
            <span class="text-off uppercase"><?php echo lang("members_clocked_in"); ?></span>

        </div>
    </div>
    <div class="box-content widget-container">
        <div class="panel-body ">
            <h1 class=""><?php echo $members_clocked_out; ?></h1>
            <span class="text-off uppercase"><?php echo lang("members_clocked_out"); ?></span>
        </div>
    </div>
</div>