<div class="app-modal">
    <div class="app-modal-content">
        <?php $this->load->view("includes/file_preview"); ?>
    </div>
</div>